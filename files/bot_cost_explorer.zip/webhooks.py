from os import environ

webhooks = {
    "chanel": environ["webhook"]
}
