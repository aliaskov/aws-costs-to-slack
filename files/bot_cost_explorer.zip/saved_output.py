output = {
    "GroupDefinitions": [
        {
            "Type": "DIMENSION",
            "Key": "SERVICE"
        }
    ],
    "ResultsByTime": [
        {
            "TimePeriod": {
                "Start": "2021-11-24",
                "End": "2021-11-25"
            },
            "Total": {

            },
            "Groups": [
                {
                    "Keys": [
                        "AWS CloudTrail"
                    ],
                    "Metrics": {
                        "UnblendedCost": {
                            "Amount": "0",
                            "Unit": "USD"
                        }
                    }
                },
                {
                    "Keys": [
                        "AWS Cost Explorer"
                    ],
                    "Metrics": {
                        "UnblendedCost": {
                            "Amount": "0.4",
                            "Unit": "USD"
                        }
                    }
                },
                {
                    "Keys": [
                        "AWS Key Management Service"
                    ],
                    "Metrics": {
                        "UnblendedCost": {
                            "Amount": "0.0333333336",
                            "Unit": "USD"
                        }
                    }
                },
                {
                    "Keys": [
                        "AWS Lambda"
                    ],
                    "Metrics": {
                        "UnblendedCost": {
                            "Amount": "0",
                            "Unit": "USD"
                        }
                    }
                },
                {
                    "Keys": [
                        "Amazon DynamoDB"
                    ],
                    "Metrics": {
                        "UnblendedCost": {
                            "Amount": "0",
                            "Unit": "USD"
                        }
                    }
                },
                {
                    "Keys": [
                        "EC2 - Other"
                    ],
                    "Metrics": {
                        "UnblendedCost": {
                            "Amount": "0.64055993",
                            "Unit": "USD"
                        }
                    }
                },
                {
                    "Keys": [
                        "Amazon Elastic Compute Cloud - Compute"
                    ],
                    "Metrics": {
                        "UnblendedCost": {
                            "Amount": "0",
                            "Unit": "USD"
                        }
                    }
                },
                {
                    "Keys": [
                        "Amazon Elastic File System"
                    ],
                    "Metrics": {
                        "UnblendedCost": {
                            "Amount": "0",
                            "Unit": "USD"
                        }
                    }
                },
                {
                    "Keys": [
                        "Amazon Simple Notification Service"
                    ],
                    "Metrics": {
                        "UnblendedCost": {
                            "Amount": "0",
                            "Unit": "USD"
                        }
                    }
                },
                {
                    "Keys": [
                        "Amazon Simple Queue Service"
                    ],
                    "Metrics": {
                        "UnblendedCost": {
                            "Amount": "0",
                            "Unit": "USD"
                        }
                    }
                },
                {
                    "Keys": [
                        "Amazon Simple Storage Service"
                    ],
                    "Metrics": {
                        "UnblendedCost": {
                            "Amount": "0.0063808",
                            "Unit": "USD"
                        }
                    }
                },
                {
                    "Keys": [
                        "AmazonCloudWatch"
                    ],
                    "Metrics": {
                        "UnblendedCost": {
                            "Amount": "0.00006",
                            "Unit": "USD"
                        }
                    }
                }
            ],
            "Estimated": True
        }
    ],
    "DimensionValueAttributes": [

    ],
    "ResponseMetadata": {
        "RequestId": "3d9693e7-f044-46bb-91ae-4f61a425338e",
        "HTTPStatusCode": 200,
        "HTTPHeaders": {
            "date": "Thu, 25 Nov 2021 15:35:09 GMT",
            "content-type": "application/x-amz-json-1.1",
            "content-length": "1342",
            "connection": "keep-alive",
            "x-amzn-requestid": "3d9693e7-f044-46bb-91ae-4f61a425338e",
            "cache-control": "no-cache"
        },
        "RetryAttempts": 0
    }
}