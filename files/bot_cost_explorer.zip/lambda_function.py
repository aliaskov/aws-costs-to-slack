from aws_connector import get_costs
from summary_generator import costs_per_service_summary
from msgs_constructor import costs_per_service_message
from slack_manager import send_message

def lambda_handler(event, context):
    
    raw_data = get_costs("eu-central-1")
    services_summary = costs_per_service_summary(raw_data)
    slack_message = costs_per_service_message(services_summary)
    send_message("chanel", slack_message)

if __name__ == '__main__':
    lambda_handler({}, {})
