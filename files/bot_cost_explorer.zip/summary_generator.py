
def costs_per_service_summary(response_dict):
    summary = {"Service_Amount": [], "Service_with_0_amount": []}
    result_by_time = response_dict["ResultsByTime"][0]
    summary["TimePeriod"] = response_dict["ResultsByTime"][0]["TimePeriod"]
    for group in result_by_time['Groups']:
        name = group["Keys"][0]
        amount = float(group["Metrics"]["UnblendedCost"]["Amount"])
        if amount == 0:
            summary["Service_with_0_amount"].append(name)
        else:
            summary["Service_Amount"].append([name, amount])

    summary["Service_Amount"] = sorted(summary["Service_Amount"], key=lambda x: x[1], reverse=True)

    return summary
