from datetime import datetime


def costs_per_service_message(summary):
    from templates import costs_per_service_template

    data = costs_per_service_template
    for tup in summary["Service_Amount"]:
       service, amount = tup
       fields = [x for x in data["blocks"] if "fields" in x][0]["fields"]
       fields[0]["text"] += f"{service}\n"
       fields[1]["text"] += f"{amount}$\n"

    start_date = datetime.strptime(summary['TimePeriod']['Start'], "%Y-%m-%d")
    end_date = datetime.strptime(summary['TimePeriod']['End'], "%Y-%m-%d")
    data["blocks"][1]["text"]["text"] = f"{start_date.strftime('%d %B %Y')} - {end_date.strftime('%d %B %Y')}"
    return data
