from json import dumps
import webhooks
from urllib3 import PoolManager
from logging import getLogger, INFO
from os import environ


logger = getLogger()
logger.setLevel(INFO)

def send_message(hook, data):
    # Creating a PoolManager instance for sending requests.
    webhook_url = webhooks.webhooks[hook]
    http = PoolManager()
    encoded_data=dumps(data).encode('utf-8')
    req = http.request(method="POST", url=webhook_url, body=encoded_data)
    status = req.status
    if status == 200:
        logger.info("Message posted to %s"%environ["slack_channel"])
    else:
        logger.error("Request failed, response code: %d"%status)