from boto3 import client
from datetime import datetime, timedelta


def get_costs(region, start=1, end=0,
              granularity="DAILY", metrics=("UnblendedCost",),
              group_by=("DIMENSION", "SERVICE")):

    now = datetime.utcnow()
    start_day = (now - timedelta(days=start)).strftime('%Y-%m-%d')
    end_day = (now - timedelta(days=end)).strftime('%Y-%m-%d')
    cd = client('ce', region)
    group_type, group_key = group_by
    data = cd.get_cost_and_usage(TimePeriod={'Start': start_day, 'End': end_day},
                                 Granularity=granularity,
                                 Metrics=metrics,
                                 GroupBy=[
                                     {
                                         'Type': group_type,
                                         'Key': group_key
                                     }
                                 ])
    return data
