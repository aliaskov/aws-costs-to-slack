costs_per_service_template = {
    "text": "Costs per service AWS bot",
        "blocks": [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": "Costs per service"
                }
            },
            {
                "type": "section",
                "text": {
                    "type": "plain_text",
                    "text": "Text",
                }
            },
            {
                "type": "section",
                "fields": [
                    {
                        "type": "mrkdwn",
                        "text": "*Service*\n"
                    },
                    {
                        "type": "mrkdwn",
                        "text": "*Amount*\n"
                    }
                ]
            }
        ]
    }